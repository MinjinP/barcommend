# barcommend
## 2020 KNU Mobile App Programming(005) Team 10

* 프로젝트 명: Barcommend
* 팀원: 박민진, 문혜원, 석혜린, 윤소현
* 프로젝트 문서
  * [프로젝트 계획서-Barcommend.pdf](https://github.com/Shyellen/SD_2020/files/5540904/2020.2._Barcommend.pdf)
